# Honorbuddy Profiles

This repository contains Honorbuddy's default profiles.

## Using the profiles

Whenever a new version of Honorbuddy is released, the latest version of the profiles are pulled from this repository, and included in the release automatically. 

If you want to obtain a copy of the profiles manually, you can download the contents of the repository as a .zip file, using the `Clone or download` -> `Download ZIP` buttons.

## Contributing

See the [Contributing document](CONTRIBUTING.md) for guidelines for making contributions.

## Discuss

You can discuss Honorbuddy in our Discord channel which can be found [here](https://discord.gg/h74WjFY).